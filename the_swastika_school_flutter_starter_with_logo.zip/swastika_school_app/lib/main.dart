
import 'package:flutter/material.dart';

void main() => runApp(const SwastikaApp());

class SwastikaApp extends StatelessWidget {
  const SwastikaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'The Swastika School',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF173B69)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String role = 'Admin';
  final phone = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.asset(
                    'assets/school_logo.jpg',
                    width: 132,
                    height: 132,
                    fit: BoxFit.contain,
                  ),
                ),
                const SizedBox(height: 18),
                const Text('THE SWASTIKA SCHOOL',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF173B69))),
                const Text('School Management App'),
                const SizedBox(height: 30),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text('Login', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 14),
                        SegmentedButton<String>(
                          segments: const [
                            ButtonSegment(value: 'Admin', label: Text('Admin'), icon: Icon(Icons.admin_panel_settings)),
                            ButtonSegment(value: 'Teacher', label: Text('Teacher'), icon: Icon(Icons.person)),
                            ButtonSegment(value: 'Parent', label: Text('Parent'), icon: Icon(Icons.family_restroom)),
                          ],
                          selected: {role},
                          onSelectionChanged: (v) => setState(() => role = v.first),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: phone,
                          keyboardType: TextInputType.phone,
                          decoration: const InputDecoration(
                            labelText: 'Mobile number',
                            prefixIcon: Icon(Icons.phone),
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 16),
                        FilledButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(
                              builder: (_) => DashboardPage(role: role),
                            ));
                          },
                          child: const Text('Continue to Demo'),
                        ),
                        const SizedBox(height: 8),
                        const Text('Demo mode: login is not connected to real accounts or OTP.',
                            textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.grey)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  final String role;
  const DashboardPage({super.key, required this.role});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int selected = 0;
  final List<String> classes = ['Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5', 'Class 6', 'Class 7', 'Class 8'];
  final Map<String, List<String>> sections = {};
  final List<Map<String, String>> notices = [
    {'title': 'Welcome to The Swastika School', 'body': 'School updates and notices will appear here.'}
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _classes(),
      _attendance(),
      _fees(),
      _notices(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('The Swastika School'),
        backgroundColor: const Color(0xFF173B69),
        foregroundColor: Colors.white,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: Text(widget.role, style: const TextStyle(fontWeight: FontWeight.w600))),
          )
        ],
      ),
      body: pages[selected],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (v) => setState(() => selected = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.class_outlined), label: 'Classes'),
          NavigationDestination(icon: Icon(Icons.fact_check_outlined), label: 'Attendance'),
          NavigationDestination(icon: Icon(Icons.currency_rupee), label: 'Fees'),
          NavigationDestination(icon: Icon(Icons.campaign_outlined), label: 'Notices'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Text('Hello, ${widget.role}!', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const Text('School overview • Demo figures'),
      const SizedBox(height: 16),
      const Wrap(spacing: 12, runSpacing: 12, children: [
        StatCard(title: 'Students', value: '850', icon: Icons.groups),
        StatCard(title: 'Teachers', value: '42', icon: Icons.co_present),
        StatCard(title: 'Attendance', value: '92%', icon: Icons.fact_check),
        StatCard(title: 'Fees due', value: 'Demo', icon: Icons.payments),
      ]),
      const SizedBox(height: 20),
      const Text('Quick access', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...['Student records', 'Teacher records', 'Homework', 'Results', 'Transport'].map((e) =>
        Card(child: ListTile(leading: const Icon(Icons.arrow_right), title: Text(e), subtitle: const Text('Module planned for next development phase')))),
    ],
  );

  Widget _classes() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Classes & Sections', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const Text('Sections can be added or edited by Admin.'),
      const SizedBox(height: 12),
      ...classes.map((c) => Card(
        child: ExpansionTile(
          title: Text(c, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text('${(sections[c] ?? []).length} sections'),
          children: [
            ...(sections[c] ?? []).map((s) => ListTile(
              title: Text(s),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => sections[c]!.remove(s)),
            )),
            TextButton.icon(
              onPressed: () => _addSection(c),
              icon: const Icon(Icons.add),
              label: const Text('Add section'),
            ),
          ],
        ),
      )),
    ],
  );

  void _addSection(String c) {
    final controller = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: Text('Add section – $c'),
      content: TextField(controller: controller, decoration: const InputDecoration(hintText: 'e.g. A, B, Jasmine')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          final value = controller.text.trim();
          if (value.isNotEmpty) setState(() => sections.putIfAbsent(c, () => []).add(value));
          Navigator.pop(context);
        }, child: const Text('Save')),
      ],
    ));
  }

  Widget _attendance() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Attendance', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const Text('Demo attendance register'),
    const SizedBox(height: 12),
    ...['Aarav Sharma', 'Anaya Verma', 'Vivaan Singh', 'Ishita Kumari'].map((name) => Card(
      child: StatefulBuilder(builder: (context, localSet) {
        bool present = true;
        return ListTile(
          title: Text(name),
          subtitle: const Text('Class 5 • Section A'),
          trailing: StatefulBuilder(builder: (context, setLocal) => Switch(
            value: present,
            onChanged: (v) { present = v; setLocal(() {}); },
          )),
        );
      }),
    )),
  ]);

  Widget _fees() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Monthly Fees', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const Text('Sample screen – no real payment is collected.'),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Demo student • Class 5 A'),
      const SizedBox(height: 8),
      const Text('November 2026', style: TextStyle(color: Colors.grey)),
      const Text('₹2,500', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const Text('Monthly fee • Sample amount'),
      const SizedBox(height: 12),
      const Chip(label: Text('Payment pending – demo')),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: () => showDialog(context: context, builder: (_) => const AlertDialog(
        title: Text('Payment setup required'),
        content: Text('Connect the school UPI ID or a verified payment gateway before accepting real payments.'),
      )), icon: const Icon(Icons.payment), label: const Text('Pay fees')),
      const Text('A receipt screen will be enabled after payment verification.', style: TextStyle(fontSize: 12, color: Colors.grey)),
    ]))),
  ]);

  Widget _notices() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('School Notices', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    if (widget.role == 'Admin') FilledButton.icon(
      onPressed: _addNotice, icon: const Icon(Icons.add), label: const Text('Create notice')),
    ...notices.map((n) => Card(child: ListTile(
      leading: const Icon(Icons.notifications_active_outlined),
      title: Text(n['title']!), subtitle: Text(n['body']!),
    ))),
  ]);

  void _addNotice() {
    final title = TextEditingController();
    final body = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('New notice'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: title, decoration: const InputDecoration(labelText: 'Title')),
        TextField(controller: body, decoration: const InputDecoration(labelText: 'Message')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          if (title.text.trim().isNotEmpty) setState(() => notices.insert(0, {'title': title.text.trim(), 'body': body.text.trim()}));
          Navigator.pop(context);
        }, child: const Text('Publish')),
      ],
    ));
  }
}

class StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: 155,
    child: Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF2467A8)),
        const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(color: Colors.grey)),
      ],
    ))),
  );
}
