# The Swastika School – Flutter starter

The school logo supplied by the user is included at `assets/school_logo.jpg`
and displayed on the login screen.

## Included in this first demo
- Role selection: Admin, Teacher, Parent (demo only; no real authentication)
- Dashboard with clearly marked sample figures
- Nursery to Class 8 class list
- Add/remove sections in the running demo
- Attendance sample screen
- Monthly fees sample screen
- Admin can create notices in the running demo
- The Swastika School logo

## Important limitations
This is a UI/MVP starter, not a production-ready school system.
- Data is held in app memory and resets when the app restarts.
- Login does not verify mobile numbers or send OTP.
- Student and teacher records, real attendance storage, parent-child linking,
  fee ledger, payment gateway, automatic payment verification, PDF receipts,
  notifications, backups and security rules still need backend implementation.
- The payment screen intentionally does not collect money. Before real payments,
  the school must set up a verified merchant UPI ID/payment gateway account.
- Do not put personal UPI details or secret keys directly in the app.

## Build an Android APK
1. Install Flutter SDK and Android Studio on a computer.
2. In a terminal, run `flutter create swastika_school`.
3. Replace the generated `lib` folder and `pubspec.yaml` with the ones in this ZIP.
   Also copy the `assets` folder.
4. Run `flutter pub get`.
5. Connect an Android phone or configure an emulator and run `flutter run`.
6. To build a shareable APK, run `flutter build apk --release`.
7. The APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

The APK build requires Flutter/Android build tools. This ZIP itself is not an installable APK.
